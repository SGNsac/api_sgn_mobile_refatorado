export const selectPag2ContrUsuaSmpCrPedCom = () => {
  return `
    SELECT 
        PAG2_CONTR_USUA_SMP_CR_PED_COM 
    FROM 
        PARAMETROS_GERAIS_2
  `
}
